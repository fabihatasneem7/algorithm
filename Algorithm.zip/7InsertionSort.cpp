#include <iostream>
using namespace std;
int main(){
	int a[]= {8,3,7,9,1};
	int i, value, hole;
	for(i= 1; i<5; i++){
		value = a[i];
		hole = i;
		while (hole > 0 && a[hole-1] > value){
			a[hole] = a[hole-1];
			hole--;
		}
		a[hole]= value;
	}
	cout << "sorted array:\n\n ";
	for(i=0; i < 5;i++){
		cout<<" "<<a[i];
	}
	return 0;
}
