#include <iostream>
#include <cstdlib>
using namespace std;

void countingSort(int arr[], int size);
int findMax(int arr[], int size);
int findMin(int arr[], int size);

int main(){

    int num = 6;
    //int arr[num] = {15,1,0,4,7,-2};
    int arr[num] = {15,2,4,1,6,-5}; //all valid
    countingSort(arr, num);

}

void countingSort(int arr[], int size){


    int min_count = findMin(arr, size);
    //cout << abs(min_count);
    if(min_count <= 0){
        for(int i=0; i<size; i++){
            arr[i] += (abs(min_count)+1);
        }
    }

    int count = findMax(arr, size);  //count = label

    int Cf[count];
    int temp[size];
    //cout << count << endl;

    for(int i=0; i<count; i++){
        Cf[i] = 0;
    }

    for(int i=0; i<size; i++){
        Cf[arr[i]-1] = Cf[arr[i]-1]+1;
    }

    for(int i=1; i<count; i++){
        Cf[i] = Cf[i]+Cf[i-1];
    }

    for(int i=size-1; i>=0; i--){
        temp[Cf[arr[i]-1]-1] = arr[i];
        Cf[arr[i]-1]--;
    }

    if(min_count <= 0){
        for(int i=0; i<size; i++){
            temp[i] -= (abs(min_count)+1);
        }
    }

    for(int i=0; i<size; i++){
        cout << temp[i] << " ";
    }
}

int findMax(int arr[], int size){
    int x = arr[0];
    for(int i=1; i<size; i++){
        if(arr[i] > x){
            x = arr[i];
        }
    }

    return x;
}

int findMin(int arr[], int size){
    int x = arr[0];
    for(int i=1; i<size; i++){
        if(arr[i] < x){
            x = arr[i];
        }
    }
    if(x <0){
        return x;
    }
    else{
        return 0;
    }
}
